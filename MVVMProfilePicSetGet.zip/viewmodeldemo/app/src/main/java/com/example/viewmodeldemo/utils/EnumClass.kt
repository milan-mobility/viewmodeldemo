package com.example.viewmodeldemo.utils

enum class EnumClass {

    SUCCESS,
    ERROR,
    LOADING
}