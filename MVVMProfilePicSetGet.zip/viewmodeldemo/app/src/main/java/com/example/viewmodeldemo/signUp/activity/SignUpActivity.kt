package com.example.viewmodeldemo.signUp.activity


import android.Manifest
import android.app.ProgressDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.FileUtils
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.viewmodeldemo.R
import com.example.viewmodeldemo.databinding.ActivitySignUpBinding
import com.example.viewmodeldemo.signIn.SignInActivity
import com.example.viewmodeldemo.utils.EnumClass
import com.example.viewmodeldemo.utils.Method
import com.example.viewmodeldemo.utils.PathUtil
import com.example.viewmodeldemo.utils.isNetworkAvailable


class SignUpActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignUpBinding
    private lateinit var signUpViewModel: SingUpViewModel
    private lateinit var method: Method
    private lateinit var progressDialog: ProgressDialog
    private lateinit var inputMethodManager: InputMethodManager
    private var GALLARY_PERMISSION_CODE = 100
    private var imagePath: String = ""


    companion object {
        var TAG = ActivitySignUpBinding::class.java.simpleName!!
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_sign_up)
        signUpViewModel = ViewModelProvider(this)[SingUpViewModel::class.java]
        progressDialog = ProgressDialog(this)

        signUpViewModel = SingUpViewModel(application)
        binding.signUpViewModel = signUpViewModel
        method = Method(this)



        inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)

        signUpViewModel.livedata.observe(this) {
            when (it.status) {
                EnumClass.SUCCESS -> {
                    Log.d("data_information", "" + it.data?.status)
                    if (it.data?.status!!) {
                        method.dialog(this, R.string.sign_up, R.string.register_success, 1)
                    } else {
                        method.dialog(this, R.string.sign_up, R.string.email_pass_exist, 0)
                    }
                    progressDialog.dismiss()

                }
                EnumClass.ERROR -> {
                    Log.d(TAG, "" + EnumClass.ERROR)
                    progressDialog.dismiss()

                }
                EnumClass.LOADING -> {
                    progressDialog.setMessage(resources.getString(R.string.loading))
                    progressDialog.setCancelable(false)
                    progressDialog.show()
                    Log.d(TAG, "" + EnumClass.LOADING)

                }
            }
        }

        binding.btnSignUp.setOnClickListener {
            inputMethodManager.hideSoftInputFromWindow(binding.inputLayoutName.windowToken, 0)
            inputMethodManager.hideSoftInputFromWindow(binding.inputLayoutEmail.windowToken, 0)

            signUpViewModel.nameError = ""
            signUpViewModel.emailError = ""
            signUpViewModel.passError = ""

            if (signUpViewModel.validationField()) {
                if (isNetworkAvailable(this)) {
                    signUpViewModel.getApiRegistration(imagePath)
                } else {
                    Toast.makeText(this, R.string.internet_connection, Toast.LENGTH_SHORT).show()
                }
            } else {
                binding.inputLayoutName.helperText = signUpViewModel.nameError
                binding.inputLayoutEmail.helperText = signUpViewModel.emailError
                binding.inputLayoutPassword.helperText = signUpViewModel.passError
            }
        }
        binding.signUp.setOnClickListener {
            startActivity(Intent(this, SignInActivity::class.java))
            finish()
        }

        binding.profilePicture.setOnClickListener {

            if (ActivityCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                openGallery()

            } else {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE),
                    GALLARY_PERMISSION_CODE
                )

            }
        }

    }

    private fun openGallery() {

        val gallary = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
        startActivityForResult(gallary, GALLARY_PERMISSION_CODE)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == GALLARY_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "permission granted", Toast.LENGTH_SHORT).show()
                openGallery()
            }
            val showRationale = shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (!showRationale) {
                val deniedDialog = AlertDialog.Builder(this)

                deniedDialog.setTitle(R.string.permission_denied)
                deniedDialog.setMessage(R.string.permission_setting)
                deniedDialog.setPositiveButton(
                    R.string.setting,
                    DialogInterface.OnClickListener { _, _ ->
                        showPermissionDeniedDialog()
                    })
                deniedDialog.setNegativeButton(R.string.cancel, null)
                deniedDialog.show()
                Toast.makeText(this, "permission denied", Toast.LENGTH_SHORT).show()
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    private fun showPermissionDeniedDialog() {

        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        val uri = Uri.fromParts(
            "package", packageName, null
        )
        intent.data = uri
        startActivity(intent)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == GALLARY_PERMISSION_CODE) {
            if (data != null) {
                val uri = data.data
                Log.d("data_information", uri.toString())
                Log.d("data_information", PathUtil.getPath(this, uri!!).toString())

                binding.profilePicture.setImageURI(uri)
                imagePath = PathUtil.getPath(this, uri).toString()

                Glide.with(binding.profilePicture)
                    .load(uri)
                    .placeholder(R.drawable.placeholder)
                    .into(binding.profilePicture)
            } else {
                Toast.makeText(this, getString(R.string.wrong), Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "not match request code", Toast.LENGTH_SHORT).show()
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
}