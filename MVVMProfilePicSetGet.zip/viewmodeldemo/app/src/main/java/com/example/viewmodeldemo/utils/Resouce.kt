package com.example.viewmodeldemo.utils

data class Resource<out T>(val status: EnumClass, val data: T?, val message: String?) {

    companion object {

        fun <T> success(data: T?): Resource<T> {
            return Resource(EnumClass.SUCCESS, data, null)
        }
        fun <T> error(msg: String, data: T?): Resource<T> {
            return Resource(EnumClass.ERROR, data, msg)
        }
        fun <T> loading(data: T?): Resource<T> {
            return Resource(EnumClass.LOADING, data, null)
        }

    }
}