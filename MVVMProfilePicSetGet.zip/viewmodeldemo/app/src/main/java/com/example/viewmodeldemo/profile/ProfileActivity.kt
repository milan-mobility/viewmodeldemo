package com.example.viewmodeldemo.profile

import android.app.ProgressDialog
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.viewmodeldemo.R
import com.example.viewmodeldemo.databinding.ActivityProfileBinding
import com.example.viewmodeldemo.preferense.Preferences
import com.example.viewmodeldemo.utils.EnumClass
import com.example.viewmodeldemo.utils.Method

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding
    lateinit var profileViewModel: ProfileViewModel
    private lateinit var prefrence: Preferences
    private lateinit var method: Method
    private lateinit var progressDialog: ProgressDialog

    companion object {
        var TAG = ProfileActivity::class.java.simpleName!!
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_profile)
        profileViewModel = ViewModelProvider(this)[ProfileViewModel::class.java]

        binding.profileModel = profileViewModel

        method = Method(this)
        prefrence = Preferences(this)
        progressDialog = ProgressDialog(this)

        profileViewModel.liveData.observe(this) {
            when (it.status) {
                EnumClass.SUCCESS -> {
                    Log.d(TAG, "" + it.data?.message)
                    if (it.data?.status!!) {
                        Log.d(
                            "data_information",
                            "http://13.233.39.120/trainee/uploads/${it.data.data.profilePicture}"
                        )
                        Glide.with(this)
                            .load(it.data.data.profilePicture)
                            .placeholder(R.drawable.placeholder)
                            .into(binding.imageViewUserProfile)
                        binding.textViewUserNameProfile.text = it.data.data.name
                    } else {
                        Toast.makeText(this, it.data.message, Toast.LENGTH_SHORT).show()
                    }
                    progressDialog.dismiss()
                }
                EnumClass.LOADING -> {
                    progressDialog.setMessage(resources.getString(R.string.loading))
                    progressDialog.setCancelable(false)
                    progressDialog.show()
                }
                EnumClass.ERROR -> {
                    Log.d(TAG, "" + EnumClass.ERROR)
                }
            }
        }
        profileViewModel.getProfileCall(this)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.item_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.logout -> {
                method.logoutDialog(this, R.string.logout, R.string.account_logout)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}