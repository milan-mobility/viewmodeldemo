package com.example.viewmodeldemo.signUp.activity


import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.viewmodeldemo.R
import com.example.viewmodeldemo.model.DataModel
import com.example.viewmodeldemo.network.ApiInterface
import com.example.viewmodeldemo.network.ApiServices
import com.example.viewmodeldemo.utils.Resource
import com.example.viewmodeldemo.utils.ResponseCodeCheck
import com.example.viewmodeldemo.utils.isValidEmail
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File


class SingUpViewModel(application: Application) : AndroidViewModel(application) {

    companion object{
        var TAG=SingUpViewModel::class.java.simpleName!!
    }

    var name: String = ""
    var email: String = ""
    var password: String = ""

    var nameError = ""
    var emailError = ""
    var passError = ""

    var responseCodeCheck: ResponseCodeCheck = ResponseCodeCheck()

    private var mutableData: MutableLiveData<Resource<DataModel>> = MutableLiveData()
    var livedata: LiveData<Resource<DataModel>> = mutableData


    private fun getSomeString(id: Int): String {
        return getApplication<Application>().resources.getString(id)
    }

    fun validationField(): Boolean {
        if (name.isEmpty()) {
            nameError = getSomeString(R.string.plz_enter_name)
            return false
        }
        if (email.isEmpty()) {
            emailError = getSomeString(R.string.plz_enter_email)
            return false
        } else if (!email.isValidEmail()) {
            emailError = getSomeString(R.string.plz_valid_email)
            return false
        }

        if (password.isEmpty()) {
            passError = getSomeString(R.string.plz_enter_pass)
            return false
        }
        return true
    }

    fun getApiRegistration(imagePath: String) {

        mutableData.value = Resource.loading(null)

        val file = File(imagePath)
        val requestFile: RequestBody = RequestBody.create(
            "multipart/form-data".toMediaTypeOrNull(),
            file
        )
        val body: MultipartBody.Part = MultipartBody.Part.createFormData("profile_picture", file.name, requestFile)
        val sendName: RequestBody = RequestBody.create("multipart/form-data".toMediaTypeOrNull(), name)
        val sendEmail: RequestBody = RequestBody.create("multipart/form-data".toMediaTypeOrNull(), email)
        val sendPassword: RequestBody = RequestBody.create("multipart/form-data".toMediaTypeOrNull(), password)

        val hashmap: HashMap<String, RequestBody> = HashMap()
        hashmap.apply {
            put("name", sendName)
            put("email", sendEmail)
            put("password", sendPassword)
        }

        val signUpCall = ApiServices.getRetrofit().create(ApiInterface::class.java)
        signUpCall.registerApiCall(body,hashmap).enqueue(object : Callback<DataModel?> {
            override fun onResponse(call: Call<DataModel?>, response: Response<DataModel?>) {
                if (response.isSuccessful) {
                    try {
                        mutableData.postValue(
                            responseCodeCheck.getResponseResult(
                                Response.success(
                                    response.body()
                                )
                            )
                        )
                    } catch (_: Exception) {
                        mutableData.postValue(
                            Resource.error(
                                getSomeString(R.string.wrong),
                                null
                            )
                        )
                    }
                }
            }
            override fun onFailure(call: Call<DataModel?>, t: Throwable) {
                mutableData.postValue(Resource.error("Not Data Found", null))

                Log.e(TAG,"Not Success")
            }
        })


    }
}




