package com.example.viewmodeldemo.utils

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import com.example.viewmodeldemo.R
import com.example.viewmodeldemo.preferense.Preferences
import com.example.viewmodeldemo.profile.ProfileActivity
import com.example.viewmodeldemo.signIn.SignInActivity
import com.example.viewmodeldemo.signUp.activity.SignUpActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class Method (private val activity: Activity){

    private lateinit var preferences: Preferences

    fun dialog(context:Context,title:Int,message:Int,isChecked:Int){
        var materialDialog=MaterialAlertDialogBuilder(context)
        materialDialog.apply {
            setTitle(title)
            setMessage(message)

        }
        materialDialog.setPositiveButton("ok") { _, _ ->

            if (title == R.string.sign_up) {
                if (isChecked == 1) {
                    activity.startActivity(Intent(context, SignInActivity::class.java))
                    activity.finishAffinity()

                }
            }
            if (title == R.string.sign_in) {
                if (isChecked == 1) {
                    activity.startActivity(Intent(context, ProfileActivity::class.java))
                    activity.finishAffinity()


                }
            }
        }
        materialDialog.show()

    }
    fun logoutDialog(context: Context,tittle:Int,message: Int){
        preferences= Preferences(context)

        val mDialog=MaterialAlertDialogBuilder(context)

        mDialog.setTitle(tittle)
        mDialog.setMessage(message)

        mDialog.setPositiveButton(R.string.ok) { _, _ ->
            preferences.editor.clear()
            preferences.editor.apply()
            activity.startActivity(Intent(activity, SignInActivity::class.java))
            activity.finishAffinity()

        }
        mDialog.setNegativeButton(R.string.cancel,null)
        mDialog.show()
    }

}