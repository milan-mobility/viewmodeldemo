package com.example.viewmodeldemo.signIn

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.viewmodeldemo.R
import com.example.viewmodeldemo.model.DataModel
import com.example.viewmodeldemo.network.ApiInterface
import com.example.viewmodeldemo.network.ApiServices
import com.example.viewmodeldemo.utils.Resource
import com.example.viewmodeldemo.utils.ResponseCodeCheck
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SignInViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        var TAG = SignInActivity::class.java.simpleName!!
    }
    var responseCodeCheck: ResponseCodeCheck = ResponseCodeCheck()

    private var mutableData: MutableLiveData<Resource<DataModel>> = MutableLiveData()
    var livedata: LiveData<Resource<DataModel>> = mutableData

    var edtEmail: String = ""
    var edtPass: String = ""
    var id: String = ""

    var emailError = ""
    var passwordError = ""

    private fun getString(plzEnterEmail: Int): String {
        return getApplication<Application>().resources.getString(plzEnterEmail)
    }

    fun signInValidation(): Boolean {

        if (edtEmail.isEmpty()) {
            emailError = getString(R.string.plz_enter_email)
            return false
        }
        if (edtPass.isEmpty()) {
            passwordError = getString(R.string.plz_enter_pass)
            return false
        }
        return true
    }

    fun getApiLogin(context: Context) {

        mutableData.value = Resource.loading(null)

        val hashmap: HashMap<String, String> = HashMap()
        hashmap.apply {
            put("email", edtEmail)
            put("password", edtPass)
        }
        val loginCall = ApiServices.getRetrofit().create(ApiInterface::class.java)

        loginCall.loginApiCall(hashmap).enqueue(object : Callback<DataModel?> {
            override fun onResponse(call: Call<DataModel?>, response: Response<DataModel?>) {
                if (response.body() != null) {
                    try {
                        mutableData.postValue(
                            responseCodeCheck.getResponseResult(
                                Response.success(
                                    response.body()
                                )
                            )
                        )
                    } catch (e: Exception) {
                        mutableData.postValue(
                            Resource.error(
                                context.resources.getString(R.string.wrong),
                                null
                            )
                        )
                    }
                }
            }
            override fun onFailure(call: Call<DataModel?>, t: Throwable) {
                Log.d(TAG, "" + t.message.toString())
                mutableData.postValue(Resource.error(context.resources.getString(R.string.wrong), null))
            }
        })

    }

}


