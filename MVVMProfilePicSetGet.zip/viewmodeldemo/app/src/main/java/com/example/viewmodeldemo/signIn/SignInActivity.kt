package com.example.viewmodeldemo.signIn

import android.annotation.SuppressLint
import android.app.ActionBar
import android.app.ProgressDialog
import android.content.Context
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.example.viewmodeldemo.R
import com.example.viewmodeldemo.databinding.ActivitySignInBinding
import com.example.viewmodeldemo.preferense.Preferences
import com.example.viewmodeldemo.utils.EnumClass
import com.example.viewmodeldemo.utils.Method
import com.example.viewmodeldemo.utils.isNetworkAvailable
import com.google.android.material.textfield.TextInputLayout

class SignInActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignInBinding
    private lateinit var signInViewModel: SignInViewModel
    private lateinit var preferense:Preferences
    private lateinit var method:Method
    private lateinit var progressDialog: ProgressDialog
    private lateinit var inputMethodManager: InputMethodManager

    companion object{
        var TAG= ActivitySignInBinding::class.java.simpleName!!
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_sign_in)
        signInViewModel = ViewModelProvider(this)[SignInViewModel::class.java]
        inputMethodManager= getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)

        binding.signInModel = signInViewModel
        method= Method(this)

        binding.signInActivity = this
        preferense=Preferences(this)
        progressDialog= ProgressDialog(this)


        signInViewModel.livedata.observe(this){
            when(it.status){
                EnumClass.SUCCESS-> {
                    if(it.data?.status!!){
                        preferense.setPrefBoolean("login",true)
                        preferense.setPrefString("id", it.data.data.id!!)
                        preferense.setPrefString("email", it.data.data.email!!)
                        method.dialog(this,R.string.sign_in,R.string.success,1)
                        progressDialog.dismiss()
                    }else{
                        method.dialog(this,R.string.sign_in,R.string.wrong,0)
                    }
                    Log.d(TAG,""+EnumClass.SUCCESS)
                    progressDialog.dismiss()


                }
                EnumClass.ERROR->{
                    Log.d(TAG,""+EnumClass.ERROR)
                    method.logoutDialog(this,R.string.sign_in,R.string.wrong)
                    progressDialog.dismiss()
                }
                EnumClass.LOADING->{
                    progressDialog.setMessage(resources.getString(R.string.loading))
                    progressDialog.setCancelable(false)
                    progressDialog.show()

                }
            }

        }
        binding.btnSignIn.setOnClickListener {

            inputMethodManager.hideSoftInputFromWindow(binding.inputLayoutEmail.windowToken,0)
            inputMethodManager.hideSoftInputFromWindow(binding.inputLayoutPassword.windowToken,0)

            signInViewModel.emailError = ""
            signInViewModel.passwordError = ""

            if (signInViewModel.signInValidation()) {
                if (isNetworkAvailable(this)) {
                    signInViewModel.getApiLogin(this)
                }else{
                    Toast.makeText(this, R.string.internet_connection, Toast.LENGTH_SHORT).show()
                }
            } else {
                binding.inputLayoutEmail.helperText = signInViewModel.emailError
                binding.inputLayoutPassword.helperText = signInViewModel.passwordError

            }

        }

    }
}