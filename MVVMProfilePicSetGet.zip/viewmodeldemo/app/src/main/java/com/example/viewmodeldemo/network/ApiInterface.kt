package com.example.viewmodeldemo.network

import com.example.viewmodeldemo.model.DataModel
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ApiInterface {

    @Multipart
    @POST("trainee/api/register.php")
    fun registerApiCall(
        @Part image: MultipartBody.Part,
        @PartMap hashMap: HashMap<String, RequestBody>
    ): Call<DataModel>

    @FormUrlEncoded
    @POST("trainee/api/login.php")
    fun loginApiCall(@FieldMap hashMap: HashMap<String, String>): Call<DataModel>

    @FormUrlEncoded
    @POST("trainee/api/profile.php")
    fun profileApiCall(@FieldMap hashMap: HashMap<String, String>): Call<DataModel>


}